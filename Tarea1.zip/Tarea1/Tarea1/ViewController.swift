//
//  ViewController.swift
//  Tarea1
//
//  Created by user211946 on 10/18/23.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func Juego(_ sender: Any) {
        performSegue(withIdentifier: "SecondScreen", sender: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

}

