//
//  SecondView.swift
//  Tarea1
//
//  Created by user211946 on 10/18/23.
//

import UIKit

var Puntuacion : Int = 0
var PuntuacionTotal : Int = 0

class SecondView: UIViewController {
    
    var NumSelect : Int = 0
    var Numeros: [UIImage] = []
    var imagenesMostradasFinal: [UIImage] = []
    let imagenes: [UIImage] = ["HardImage1", "HardImage2", "HardImage3"].compactMap { UIImage(named: $0) }
    @IBOutlet var ImageDisplay: UIImageView!
    @IBOutlet var Botones: [UIButton]!
    var imagenesMostradas = Set<UIImage>()
    var imagenActual: UIImage?
    var timer: Timer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(cambiarImagen), userInfo: nil, repeats: true)
    }
    
    @IBAction func OnTapImage(_ sender: UIButton) {
        for i in 0 ..< Botones.count {
            if sender == Botones[i]{
                print("Boton pulsado")
                if Numeros.count < 6 {
                    
                    if i == 0 {
                        if let HardImage1 = UIImage(named: "HardImage1") {
                            Numeros.append(HardImage1) // Agrega la nueva imagen al array
                        }
                    }
                    if i == 1 {
                        if let HardImage2 = UIImage(named: "HardImage2") {
                            Numeros.append(HardImage2) // Agrega la nueva imagen al array
                        }
                    }
                    if i == 2 {
                        if let HardImage3 = UIImage(named: "HardImage3") {
                            Numeros.append(HardImage3) // Agrega la nueva imagen al array
                        }
                    }
                    if i == 3 {
                        if let HardImage4 = UIImage(named: "HardImage4") {
                            Numeros.append(HardImage4) // Agrega la nueva imagen al array
                        }
                    }
                    if i == 4 {
                        if let HardImage5 = UIImage(named: "HardImage5") {
                            Numeros.append(HardImage5) // Agrega la nueva imagen al array
                        }
                    }
                    if i == 5 {
                        if let HardImage6 = UIImage(named: "HardImage6") {
                            Numeros.append(HardImage6) // Agrega la nueva imagen al array
                        }
                    }
                    if Numeros.count == 6{
                        compararArraysDeImagenes()
                    }
                    Botones[i].isEnabled = false
                    print(Numeros.count)
                    
                }
            }
        }
    }
    @objc func cambiarImagen() {
           // Comprueba si se han mostrado todas las imágenes
           if imagenesMostradas.count == imagenes.count {
               // Detén el temporizador porque se han mostrado todas las imágenes
               timer?.invalidate()
               timer = nil
               return
           }
           
           // Obtén una imagen aleatoria que aún no se haya mostrado
           var imagenAleatoria: UIImage?
           repeat {
               imagenAleatoria = imagenes.randomElement()
           } while imagenesMostradas.contains(imagenAleatoria!)
           
           // Muestra la imagen en el UIImageView
           if let imagen = imagenAleatoria {
               ImageDisplay.image = imagen
               imagenActual = imagen
               imagenesMostradas.insert(imagen)
           }
       }
    func compararArraysDeImagenes(){
        Puntuacion = 0
        imagenesMostradasFinal = Array(imagenesMostradas)
        print("ha llegado")
        for i in 0..<imagenesMostradasFinal.count{
            print(imagenesMostradasFinal[i] , Numeros[i])
            if imagenesMostradasFinal[i] == Numeros[i]{
                Puntuacion+=1
                print(Puntuacion, "puntos")
                if Puntuacion == 6 {
                    PuntuacionTotal += 1
                }
            }
        }
        performSegue(withIdentifier: "PuntuationView", sender: nil)
    }
}
