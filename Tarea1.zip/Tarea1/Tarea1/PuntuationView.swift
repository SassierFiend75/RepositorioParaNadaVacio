//
//  Puntuation View.swift
//  Tarea1
//
//  Created by user211946 on 11/7/23.
//

import UIKit
import Foundation
//import Supabase
class PuntuationView: UIViewController {
    var PuntosObtenidos = Puntuacion
    var NivelesCompletados = PuntuacionTotal
    var Tries: Int = 0
    var Nombre: String = ""
    @IBOutlet weak var Completados: UILabel!
    @IBOutlet weak var Intentos: UILabel!
    @IBOutlet weak var Acertados: UILabel!
    @IBOutlet weak var CampoDeTexto: UITextField!
    @IBOutlet weak var Continuar: UIButton!
    
    override func viewDidLoad() {
        CambiarLabels()
        Continuar.addTarget(self, action: #selector(ContinuarTapped), for: .touchUpInside)

    }
    func CambiarLabels() {
        Tries += 1
        Completados.text = String(PuntuacionTotal)
        Intentos.text = String(Tries)
        Acertados.text = String(Puntuacion)
        
    }
    
    @objc func ContinuarTapped() {
            recogerTexto()
            performSegue(withIdentifier: "SecondScreen", sender: nil)
            
        }
    
    func recogerTexto() {
            if let textoRecogido = CampoDeTexto.text {
                print("Texto recogido: \(textoRecogido)")
                Nombre = textoRecogido
            } else {
                print("El campo de texto está vacío.")
            }
        }

        // Implementa el método del delegado para ocultar el teclado cuando se presiona Return
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            textField.resignFirstResponder()
            return true
        }
   /* func SubirCosasBaseDeDatos(){
        Task {
                    if let user = txtField.text, !Nombre.isEmpty {
                        // Crear una instancia de Score
                        let newEntrada = Entrada(name: Nombre, score: punt)
                        print(newGatito)
                        do {
                            _ = try await supabase.database
                                .from("Nombre")
                                .insert(values: [newEntrada])
                                .execute()
                        } catch {
                            print("Error al insertar la fila en la base de datos: \(error)")
                        }
                    }
                }
            }*/
    }
     //https://github.com/supabase/supabase-swift.git
}
